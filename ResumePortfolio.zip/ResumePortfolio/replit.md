# Snehal Ghodke Portfolio

## Overview

This is a personal portfolio website for Snehal Ghodke, an AI/ML Engineer and Software Developer. The application is a single-page portfolio showcasing professional experience, technical skills, projects, certifications, and contact information. Built as a modern, responsive web application with a clean, professional aesthetic inspired by contemporary tech portfolios.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool and development server.

**UI Component System**: Leverages shadcn/ui component library (New York style variant) built on Radix UI primitives. This provides a comprehensive set of accessible, customizable components including buttons, cards, badges, dialogs, navigation menus, and form elements. All UI components follow a consistent design system with CSS variables for theming.

**Styling Approach**: Tailwind CSS with custom configuration for design tokens. The design system uses:
- HSL-based color system with CSS variables for light/dark theme support
- Custom spacing primitives (4, 6, 8, 12, 16, 20, 24 Tailwind units)
- Typography hierarchy using Inter/DM Sans fonts
- Elevation system with hover and active states (`hover-elevate`, `active-elevate-2`)
- Responsive breakpoints for mobile-first design

**State Management**: TanStack Query (React Query) for server state management with custom query client configuration. Local UI state managed with React hooks.

**Routing**: Wouter for lightweight client-side routing (currently single-page with home route and 404 fallback).

**Theme System**: Custom theme provider supporting light/dark modes with localStorage persistence and system-level theme toggling.

**Data Architecture**: Portfolio content is statically defined in TypeScript with Zod schemas for type safety. Data includes personal information, skills categorized by domain, work experiences, projects, education, and certifications.

### Backend Architecture

**Server Framework**: Express.js with TypeScript running on Node.js.

**Development Setup**: Vite middleware mode integrated with Express for hot module replacement during development. Production mode serves pre-built static assets.

**API Structure**: RESTful API pattern with `/api` prefix for all application routes (currently minimal backend logic as portfolio is content-driven).

**Storage Interface**: Abstracted storage layer with `IStorage` interface. Currently implements `MemStorage` (in-memory storage) for user management, designed to be swappable with database-backed implementation.

**Session Management**: Express session configuration with `connect-pg-simple` for PostgreSQL session store support (configured but not actively used in current portfolio implementation).

### Data Storage

**Database ORM**: Drizzle ORM configured for PostgreSQL via Neon serverless driver.

**Schema Management**: Database schemas defined in `shared/schema.ts` using Zod for runtime validation and type generation. Includes schemas for:
- Portfolio data structure (skills, experiences, projects, certifications)
- User management (prepared for future authentication features)

**Migration Strategy**: Drizzle Kit configured for schema migrations with migrations output to `./migrations` directory.

**Current Data Approach**: Portfolio content is currently statically defined in the frontend (`client/src/lib/portfolio-data.ts`). The database infrastructure is prepared but not actively used for content storage, allowing for future migration to dynamic CMS-like functionality.

### Build and Deployment

**Build Process**: 
- Frontend: Vite builds React application to `dist/public`
- Backend: esbuild bundles Express server to `dist/index.js` as ESM module
- TypeScript compilation with strict mode and path aliases

**Module System**: Full ESM (ES Modules) throughout the stack.

**Environment Configuration**: Database connection via `DATABASE_URL` environment variable for Neon PostgreSQL.

### Design System Integration

**Component Library**: Comprehensive UI component collection from shadcn/ui including:
- Layout components (Card, Sheet, Dialog, Popover)
- Navigation components (Navigation Menu, Breadcrumb, Tabs)
- Form components (Input, Textarea, Checkbox, Radio, Select)
- Feedback components (Toast, Alert, Progress)
- Data display (Table, Badge, Avatar, Separator)

**Accessibility**: All components built on Radix UI primitives ensuring WCAG compliance and keyboard navigation support.

**Responsive Design**: Mobile-first approach with custom `useIsMobile` hook (768px breakpoint) for conditional rendering and behavior.

## External Dependencies

### Core Frameworks and Libraries

- **React 18**: UI framework with TypeScript support
- **Vite**: Build tool and development server with HMR
- **Express**: Node.js web application framework
- **TypeScript**: Static type checking across full stack

### UI and Styling

- **Tailwind CSS**: Utility-first CSS framework with PostCSS and Autoprefixer
- **Radix UI**: Headless UI component primitives (20+ component packages)
- **shadcn/ui**: Pre-built component library built on Radix UI
- **class-variance-authority**: CVA for component variant management
- **Lucide React**: Icon library for UI elements
- **Embla Carousel**: Carousel/slider component library

### Data and State Management

- **TanStack Query v5**: Server state management and caching
- **Zod**: Runtime type validation and schema definition
- **Drizzle ORM**: TypeScript ORM for database operations
- **Drizzle Zod**: Integration between Drizzle schemas and Zod validation

### Database and Session

- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **connect-pg-simple**: PostgreSQL session store for Express

### Development and Build Tools

- **tsx**: TypeScript execution for development server
- **esbuild**: Fast JavaScript bundler for production builds
- **Wouter**: Lightweight routing library for React
- **date-fns**: Date utility library

### Replit Integration

- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling (non-production)
- **@replit/vite-plugin-dev-banner**: Development environment indicator (non-production)

### Form Handling

- **React Hook Form**: Form state management (via @hookform/resolvers)
- **cmdk**: Command menu component for keyboard-driven interfaces

### Additional Utilities

- **nanoid**: Unique ID generation
- **clsx & tailwind-merge**: Utility for conditional className merging