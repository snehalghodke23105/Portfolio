import { z } from "zod";

export const skillCategorySchema = z.object({
  category: z.string(),
  skills: z.array(z.string()),
});

export const experienceSchema = z.object({
  id: z.string(),
  company: z.string(),
  role: z.string(),
  period: z.string(),
  achievements: z.array(z.string()),
});

export const projectSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  technologies: z.array(z.string()),
  status: z.enum(['completed', 'in-progress']).optional(),
});

export const certificationSchema = z.object({
  id: z.string(),
  name: z.string(),
  provider: z.string(),
});

export const portfolioDataSchema = z.object({
  name: z.string(),
  title: z.string(),
  location: z.string(),
  phone: z.string(),
  email: z.string(),
  linkedin: z.string(),
  github: z.string(),
  summary: z.string(),
  skillCategories: z.array(skillCategorySchema),
  experiences: z.array(experienceSchema),
  projects: z.array(projectSchema),
  education: z.object({
    institution: z.string(),
    degree: z.string(),
    gpa: z.string(),
    period: z.string(),
  }),
  certifications: z.array(certificationSchema),
});

export type SkillCategory = z.infer<typeof skillCategorySchema>;
export type Experience = z.infer<typeof experienceSchema>;
export type Project = z.infer<typeof projectSchema>;
export type Certification = z.infer<typeof certificationSchema>;
export type PortfolioData = z.infer<typeof portfolioDataSchema>;
