import { Card } from "@/components/ui/card";
import { Code, Briefcase, Award } from "lucide-react";
import { portfolioData } from "@/lib/portfolio-data";

export function About() {
  const totalSkills = portfolioData.skillCategories.reduce(
    (acc, cat) => acc + cat.skills.length,
    0
  );

  return (
    <section
      id="about"
      className="py-20 px-6 scroll-mt-20"
      data-testid="section-about"
    >
      <div className="max-w-6xl mx-auto">
        <div className="space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            About Me
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <div className="text-base md:text-lg leading-relaxed text-muted-foreground">
              <p data-testid="text-about-summary">{portfolioData.summary}</p>
            </div>
          </div>

          <div className="space-y-6">
            <Card className="p-6 md:p-8">
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <div className="flex justify-center">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-primary" data-testid="text-years-experience">
                    3+
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Years Experience
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <div className="flex justify-center">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Code className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-primary" data-testid="text-projects-completed">
                    {portfolioData.projects.length}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Projects Completed
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <div className="flex justify-center">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Award className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-primary" data-testid="text-technologies-mastered">
                    {totalSkills}+
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Technologies Mastered
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-muted-foreground">
                    Education
                  </div>
                  <div className="text-base font-semibold" data-testid="text-education-degree">
                    {portfolioData.education.degree}
                  </div>
                  <div className="text-sm text-muted-foreground" data-testid="text-education-institution">
                    {portfolioData.education.institution}
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">GPA:</span>
                    <span className="font-semibold text-primary" data-testid="text-education-gpa">
                      {portfolioData.education.gpa}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground" data-testid="text-education-period">
                    {portfolioData.education.period}
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">
                  Location
                </div>
                <div className="text-base" data-testid="text-location">{portfolioData.location}</div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
