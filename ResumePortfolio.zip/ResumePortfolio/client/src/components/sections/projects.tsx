import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Clock } from "lucide-react";
import { portfolioData } from "@/lib/portfolio-data";

export function Projects() {
  return (
    <section
      id="projects"
      className="py-20 px-6 bg-muted/30 scroll-mt-20"
      data-testid="section-projects"
    >
      <div className="max-w-6xl mx-auto">
        <div className="space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Featured Projects
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {portfolioData.projects.map((project) => (
            <Card
              key={project.id}
              className="group overflow-hidden hover-elevate transition-all duration-300"
              data-testid={`card-project-${project.id}`}
            >
              <div className="aspect-video bg-gradient-to-br from-primary/10 via-accent/10 to-primary/5 relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center p-6 space-y-2">
                    <div className="text-6xl font-bold text-primary/20">
                      {project.title.split(' ')[0]}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {project.status === 'in-progress' && (
                        <Badge variant="secondary" className="gap-1">
                          <Clock className="h-3 w-3" />
                          In Progress
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 md:p-8 space-y-4">
                <div className="flex flex-wrap gap-2">
                  {project.technologies.slice(0, 4).map((tech) => (
                    <Badge
                      key={tech}
                      variant="outline"
                      className="text-xs"
                      data-testid={`badge-tech-${tech.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {tech}
                    </Badge>
                  ))}
                  {project.technologies.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{project.technologies.length - 4}
                    </Badge>
                  )}
                </div>

                <div className="space-y-3">
                  <h3 className="text-2xl font-bold group-hover:text-primary transition-colors" data-testid={`text-project-title-${project.id}`}>
                    {project.title}
                  </h3>
                  <p className="text-sm md:text-base leading-relaxed text-muted-foreground" data-testid={`text-project-description-${project.id}`}>
                    {project.description}
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:gap-3 transition-all"
                    data-testid={`button-view-project-${project.id}`}
                  >
                    View Details
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
