import { ArrowRight, Mail, Phone, Github, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { portfolioData } from "@/lib/portfolio-data";

export function Hero() {
  const scrollToProjects = () => {
    const element = document.querySelector("#projects");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      className="min-h-screen flex items-center justify-center px-6 pt-20 pb-12 relative overflow-hidden"
      data-testid="section-hero"
    >
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
      
      <div className="absolute inset-0 -z-10 opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto w-full">
        <div className="grid md:grid-cols-5 gap-12 items-center">
          <div className="md:col-span-3 space-y-8">
            <div className="space-y-4">
              <div className="inline-block">
                <span className="text-sm font-medium text-primary px-3 py-1 bg-primary/10 rounded-full">
                  Available for opportunities
                </span>
              </div>
              
              <h1
                className="text-5xl md:text-7xl font-bold font-display tracking-tight"
                data-testid="text-hero-name"
              >
                <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent animate-gradient">
                  {portfolioData.name}
                </span>
              </h1>
              
              <p
                className="text-2xl md:text-3xl font-semibold text-muted-foreground"
                data-testid="text-hero-title"
              >
                {portfolioData.title}
              </p>
            </div>

            <div className="space-y-4 text-base md:text-lg leading-relaxed text-muted-foreground max-w-2xl">
              <p>
                Building <span className="text-foreground font-semibold">intelligent AI/ML solutions</span> that solve real-world problems
              </p>
              <p>
                Expert in <span className="text-foreground font-semibold">full-stack development</span> with a passion for creating scalable applications
              </p>
              <p>
                Specialized in <span className="text-foreground font-semibold">Python, TensorFlow, AWS,</span> and modern web technologies
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                onClick={scrollToProjects}
                className="group"
                data-testid="button-view-projects"
              >
                View Projects
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={scrollToContact}
                data-testid="button-get-in-touch"
              >
                Get in Touch
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href={`mailto:${portfolioData.email}`}
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate px-3 py-2 rounded-md"
                data-testid="link-email"
              >
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">{portfolioData.email}</span>
              </a>
              <a
                href={`tel:${portfolioData.phone}`}
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate px-3 py-2 rounded-md"
                data-testid="link-phone"
              >
                <Phone className="h-4 w-4" />
                <span className="hidden sm:inline">{portfolioData.phone}</span>
              </a>
              <a
                href={portfolioData.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate px-3 py-2 rounded-md"
                data-testid="link-linkedin"
              >
                <Linkedin className="h-4 w-4" />
                <span className="hidden sm:inline">LinkedIn</span>
              </a>
              <a
                href={portfolioData.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate px-3 py-2 rounded-md"
                data-testid="link-github"
              >
                <Github className="h-4 w-4" />
                <span className="hidden sm:inline">GitHub</span>
              </a>
            </div>
          </div>

          <div className="md:col-span-2 flex justify-center">
            <div className="relative">
              <div className="w-full max-w-md aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 backdrop-blur-sm border border-border p-8 flex items-center justify-center">
                <div className="text-center space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <div className="text-4xl font-bold text-primary">3+</div>
                      <div className="text-sm text-muted-foreground">Internships</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-4xl font-bold text-primary">4</div>
                      <div className="text-sm text-muted-foreground">Projects</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-4xl font-bold text-primary">5</div>
                      <div className="text-sm text-muted-foreground">Certifications</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-4xl font-bold text-primary">25+</div>
                      <div className="text-sm text-muted-foreground">Technologies</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur-2xl -z-10 opacity-50" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
