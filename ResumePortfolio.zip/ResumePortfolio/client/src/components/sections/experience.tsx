import { Card } from "@/components/ui/card";
import { Check, Briefcase } from "lucide-react";
import { portfolioData } from "@/lib/portfolio-data";

export function Experience() {
  return (
    <section
      id="experience"
      className="py-20 px-6 scroll-mt-20"
      data-testid="section-experience"
    >
      <div className="max-w-6xl mx-auto">
        <div className="space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Experience
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
        </div>

        <div className="relative">
          <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2 hidden md:block" />

          <div className="space-y-12">
            {portfolioData.experiences.map((exp, index) => (
              <div
                key={exp.id}
                className={`relative grid md:grid-cols-2 gap-8 ${
                  index % 2 === 0 ? "md:text-right" : "md:flex-row-reverse"
                }`}
                data-testid={`card-experience-${exp.id}`}
              >
                <div
                  className={`${
                    index % 2 === 0
                      ? "md:col-start-1"
                      : "md:col-start-2"
                  }`}
                >
                  <Card className="p-6 md:p-8 space-y-4 hover-elevate transition-transform h-full">
                    <div className="flex items-start gap-3 md:justify-end">
                      <div
                        className={`flex-1 space-y-2 ${
                          index % 2 === 0 ? "md:text-right" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2 md:justify-end">
                          <Briefcase className="h-5 w-5 text-primary flex-shrink-0" />
                          <h3 className="text-xl md:text-2xl font-semibold" data-testid={`text-exp-role-${exp.id}`}>
                            {exp.role}
                          </h3>
                        </div>
                        <div className="text-base font-medium text-primary" data-testid={`text-exp-company-${exp.id}`}>
                          {exp.company}
                        </div>
                        <div className="text-sm text-muted-foreground" data-testid={`text-exp-period-${exp.id}`}>
                          {exp.period}
                        </div>
                      </div>
                    </div>

                    <ul
                      className={`space-y-3 ${
                        index % 2 === 0 ? "md:text-right" : ""
                      }`}
                    >
                      {exp.achievements.map((achievement, idx) => (
                        <li
                          key={idx}
                          className={`flex gap-3 items-start text-sm md:text-base leading-relaxed ${
                            index % 2 === 0 ? "md:flex-row-reverse" : ""
                          }`}
                        >
                          <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground" data-testid={`text-exp-achievement-${exp.id}-${idx}`}>
                            {achievement}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </div>

                <div className="hidden md:flex items-center justify-center absolute left-1/2 top-8 -translate-x-1/2">
                  <div className="w-4 h-4 rounded-full bg-primary border-4 border-background" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
