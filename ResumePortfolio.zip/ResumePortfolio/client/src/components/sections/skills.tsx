import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { portfolioData } from "@/lib/portfolio-data";

export function Skills() {
  return (
    <section
      id="skills"
      className="py-20 px-6 bg-muted/30 scroll-mt-20"
      data-testid="section-skills"
    >
      <div className="max-w-6xl mx-auto">
        <div className="space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Technical Skills
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioData.skillCategories.map((category) => (
            <Card
              key={category.category}
              className="p-6 space-y-4 hover-elevate transition-transform"
              data-testid={`card-skill-category-${category.category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <h3 className="text-xl font-semibold">{category.category}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="text-sm"
                    data-testid={`badge-skill-${skill.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
