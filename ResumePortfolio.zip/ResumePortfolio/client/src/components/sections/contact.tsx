import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Github, Linkedin, MapPin, Copy, Check } from "lucide-react";
import { portfolioData } from "@/lib/portfolio-data";
import { useState } from "react";

export function Contact() {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  const copyToClipboard = async (text: string, type: 'email' | 'phone') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'email') {
        setCopiedEmail(true);
        setTimeout(() => setCopiedEmail(false), 2000);
      } else {
        setCopiedPhone(true);
        setTimeout(() => setCopiedPhone(false), 2000);
      }
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <section
      id="contact"
      className="py-24 px-6 bg-gradient-to-br from-primary/5 via-background to-accent/5 scroll-mt-20"
      data-testid="section-contact"
    >
      <div className="max-w-4xl mx-auto text-center">
        <div className="space-y-6 mb-12">
          <h2 className="text-3xl md:text-5xl font-bold font-display">
            Let's Build Something Amazing
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
          </p>
        </div>

        <Card className="p-8 md:p-12 space-y-8 max-w-2xl mx-auto">
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                <div className="flex-1 text-left">
                  <div className="text-xs text-muted-foreground mb-1">Email</div>
                  <a
                    href={`mailto:${portfolioData.email}`}
                    className="text-sm font-medium text-foreground hover:text-primary transition-colors break-all"
                    data-testid="link-contact-email"
                  >
                    {portfolioData.email}
                  </a>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="flex-shrink-0"
                  onClick={() => copyToClipboard(portfolioData.email, 'email')}
                  data-testid="button-copy-email"
                >
                  {copiedEmail ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                <div className="flex-1 text-left">
                  <div className="text-xs text-muted-foreground mb-1">Phone</div>
                  <a
                    href={`tel:${portfolioData.phone}`}
                    className="text-sm font-medium text-foreground hover:text-primary transition-colors"
                    data-testid="link-contact-phone"
                  >
                    {portfolioData.phone}
                  </a>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="flex-shrink-0"
                  onClick={() => copyToClipboard(portfolioData.phone, 'phone')}
                  data-testid="button-copy-phone"
                >
                  {copiedPhone ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-muted-foreground justify-center">
            <MapPin className="h-5 w-5 text-primary flex-shrink-0" />
            <div className="text-sm">
              <span className="font-medium text-foreground">{portfolioData.location}</span>
            </div>
          </div>

          <div className="pt-6 border-t border-border">
            <div className="flex justify-center gap-4">
              <Button
                size="lg"
                variant="outline"
                asChild
                data-testid="button-linkedin"
              >
                <a
                  href={portfolioData.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gap-2"
                >
                  <Linkedin className="h-5 w-5" />
                  LinkedIn
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                data-testid="button-github"
              >
                <a
                  href={portfolioData.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gap-2"
                >
                  <Github className="h-5 w-5" />
                  GitHub
                </a>
              </Button>
            </div>
          </div>
        </Card>

        <div className="mt-12 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} {portfolioData.name}. Built with passion and code.</p>
        </div>
      </div>
    </section>
  );
}
