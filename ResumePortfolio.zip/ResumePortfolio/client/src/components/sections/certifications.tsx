import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award } from "lucide-react";
import { portfolioData } from "@/lib/portfolio-data";

export function Certifications() {
  return (
    <section
      className="py-20 px-6 scroll-mt-20"
      data-testid="section-certifications"
    >
      <div className="max-w-6xl mx-auto">
        <div className="space-y-4 mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Certifications
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioData.certifications.map((cert) => (
            <Card
              key={cert.id}
              className="p-6 space-y-4 hover-elevate transition-transform"
              data-testid={`card-certification-${cert.id}`}
            >
              <div className="flex items-start gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Award className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 space-y-2">
                  <h3 className="font-semibold text-base leading-tight" data-testid={`text-cert-name-${cert.id}`}>
                    {cert.name}
                  </h3>
                  <Badge variant="secondary" className="text-xs" data-testid={`text-cert-provider-${cert.id}`}>
                    {cert.provider}
                  </Badge>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
