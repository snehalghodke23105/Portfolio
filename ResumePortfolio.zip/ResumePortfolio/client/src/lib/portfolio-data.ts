import type { PortfolioData } from "@shared/schema";

export const portfolioData: PortfolioData = {
  name: "Snehal Ghodke",
  title: "AI/ML Engineer & Software Developer",
  location: "India",
  phone: "+91 7276996159",
  email: "sg8698367@gmail.com",
  linkedin: "https://linkedin.com/in/snehal-ghodke",
  github: "https://github.com/snehalghodke",
  summary: "Energetic and detail-oriented AI/ML Engineer & Software Developer skilled in designing, developing, and deploying intelligent, scalable applications. Proficient in Python, Java, and C++, with expertise across machine learning, generative AI, and full-stack web development. Adept at applying data-driven methodologies and modern tools (AWS, Azure, TensorFlow, LangChain, Docker) to build real-world AI solutions. Passionate about continuous learning, innovation, and collaboration in dynamic tech environments.",
  skillCategories: [
    {
      category: "Programming",
      skills: ["Python", "Java", "C++", "C", ".NET", "SQL"]
    },
    {
      category: "AI/ML & Data Science",
      skills: ["TensorFlow", "PyTorch", "Scikit-learn", "Hugging Face", "LangChain", "Azure ML Studio"]
    },
    {
      category: "Cloud & DevOps",
      skills: ["AWS", "Azure", "Docker", "Git", "GitHub"]
    },
    {
      category: "Databases",
      skills: ["MySQL", "MongoDB", "Oracle", "Teradata"]
    },
    {
      category: "Web Development",
      skills: ["HTML", "CSS", "JavaScript", "React", "Node.js"]
    },
    {
      category: "Tools & Visualization",
      skills: ["Tableau", "Power BI", "Postman"]
    },
    {
      category: "Core Competencies",
      skills: ["Data Structures", "Algorithms", "OOP", "Agile SDLC", "Debugging", "Problem-Solving"]
    }
  ],
  experiences: [
    {
      id: "exp-1",
      company: "Hype Intern",
      role: "Full Stack Developer Intern",
      period: "Aug 2024 – Sep 2024",
      achievements: [
        "Designed and developed responsive web applications (E-learning platform, Real Estate site, Chat app)",
        "Integrated MongoDB and MySQL backends, improving data access and response time by 25%",
        "Led feature optimization, debugging, and deployment in Agile sprints",
        "Built project dashboards and reports for stakeholder updates"
      ]
    },
    {
      id: "exp-2",
      company: "Cognifyz",
      role: "Java Developer Intern",
      period: "Feb 2024 – Mar 2024",
      achievements: [
        "Developed Java concurrency solutions using threads, synchronization, and locks for system stability",
        "Enhanced application performance through structured problem-solving and code optimization",
        "Collaborated in Agile teams, contributing to peer reviews and design discussions"
      ]
    },
    {
      id: "exp-3",
      company: "Codsoft",
      role: "Web Developer Intern",
      period: "Sep 2023 – Oct 2023",
      achievements: [
        "Created responsive web apps using HTML, CSS, JavaScript, and Java",
        "Conducted iterative testing and debugging for efficient UI/UX delivery",
        "Improved usability and performance across multiple projects"
      ]
    }
  ],
  projects: [
    {
      id: "proj-1",
      title: "Helmet Detection with CNN",
      description: "Built and trained a deep learning model for helmet detection to enhance safety compliance. Applied CNN architectures using TensorFlow and OpenCV; implemented real-time detection via webcam feed.",
      technologies: ["TensorFlow", "OpenCV", "Python", "CNN", "Computer Vision"],
      status: "completed"
    },
    {
      id: "proj-2",
      title: "Gesture-Sensitive Learning App",
      description: "Designed an AI-powered educational app for preschoolers using gesture recognition and NLP. Integrated machine learning models for interactive feedback and adaptive learning.",
      technologies: ["Machine Learning", "NLP", "Gesture Recognition", "Python"],
      status: "completed"
    },
    {
      id: "proj-3",
      title: "E-Commerce Price Tracker",
      description: "Developed an automated Python + SQL tool to track price variations across e-commerce sites. Utilized BeautifulSoup and scheduling scripts to enhance performance monitoring.",
      technologies: ["Python", "SQL", "BeautifulSoup", "Web Scraping"],
      status: "completed"
    },
    {
      id: "proj-4",
      title: "NLP Chatbot",
      description: "Building a LangChain + Hugging Face chatbot for Q&A and content retrieval tasks. Exploring prompt engineering and LLM fine-tuning for domain-specific tasks.",
      technologies: ["LangChain", "Hugging Face", "NLP", "Python", "LLM"],
      status: "in-progress"
    }
  ],
  education: {
    institution: "Nutan College of Engineering and Research – Pune",
    degree: "B.Tech, Computer Science & Engineering",
    gpa: "7.98",
    period: "Dec 2021 – Jun 2025"
  },
  certifications: [
    {
      id: "cert-1",
      name: "Machine Learning Pipelines with Azure ML Studio",
      provider: "Coursera"
    },
    {
      id: "cert-2",
      name: "Prompt Design in Vertex AI",
      provider: "Google"
    },
    {
      id: "cert-3",
      name: "Data Analytics on Azure",
      provider: "Microsoft"
    },
    {
      id: "cert-4",
      name: "Python Programming",
      provider: "GUVI"
    },
    {
      id: "cert-5",
      name: "C++ Programming",
      provider: "Code Crawlers Academy"
    }
  ]
};
