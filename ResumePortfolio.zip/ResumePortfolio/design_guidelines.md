# Design Guidelines: Snehal Ghodke Portfolio

## Design Approach
**Reference-Based Approach** drawing from modern tech portfolios (Linear's clarity, Stripe's sophistication, and contemporary developer portfolios). Clean, professional aesthetic that emphasizes content hierarchy and readability while showcasing technical expertise.

## Layout System
**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16, 20, 24 for consistent rhythm
- Section padding: py-20 (desktop), py-12 (mobile)
- Component gaps: gap-8 for cards, gap-6 for lists
- Container: max-w-6xl with px-6

## Typography Hierarchy
**Font Stack**: 
- Primary: Inter or DM Sans (headings, UI elements)
- Secondary: System UI (body text)

**Scales**:
- Hero headline: text-5xl md:text-7xl, font-bold
- Section headers: text-3xl md:text-4xl, font-bold
- Subsection headers: text-xl md:text-2xl, font-semibold
- Body: text-base md:text-lg, leading-relaxed
- Small text: text-sm

## Core Sections & Layout

### 1. Hero Section (Full viewport height)
**Layout**: Asymmetric split with text-dominant left side (60%) and visual element right (40%)
- Large name display with animated gradient text effect
- Tagline: "AI/ML Engineer & Software Developer"
- Three-line value proposition highlighting AI/ML expertise, full-stack capabilities, problem-solving
- Primary CTA: "View Projects" + Secondary: "Download Resume"
- Social links (LinkedIn, GitHub) as icon buttons
- Background: Subtle gradient mesh or geometric pattern overlay

**Image**: Abstract tech visualization or coding workspace scene (right side, partially overlapping text area for depth)

### 2. About/Skills Section
**Layout**: Two-column on desktop (biography left, quick stats right)
- Biography: 2-3 paragraphs from summary, text-lg
- Quick stats card: Years of experience, Projects completed, Technologies mastered
- Skill categories as interactive tag clouds or organized grids

**Technical Skills Display**: 
Multi-category grid (3 columns on desktop, 1 on mobile):
- Programming Languages
- AI/ML & Data Science
- Cloud & DevOps
- Databases & Web Dev

Each skill as pill/badge component with icon (from Heroicons)

### 3. Experience Timeline
**Layout**: Vertical timeline with alternating card positions (zigzag desktop, stacked mobile)
- Each role: Company logo placeholder, title, dates, location
- Bullet achievements with checkmark icons
- Visual timeline connector line with date markers
- Spacing: gap-12 between entries

### 4. Projects Showcase (Critical Section)
**Layout**: Masonry-style grid (2 columns desktop, 1 mobile)

**Featured Projects** (4 cards with varying heights):
1. **Helmet Detection CNN** - Large card with demo image placeholder
2. **Gesture-Sensitive Learning App** - Medium card with app interface mockup
3. **E-Commerce Price Tracker** - Medium card with dashboard visualization
4. **NLP Chatbot** - Large card with chat interface preview

Each card includes:
- Project thumbnail image (400x300px minimum)
- Tech stack badges at top
- Title (text-2xl font-bold)
- 2-3 sentence description
- "View Details" link with arrow icon
- Hover: Subtle lift effect and image zoom

**Images**: Create placeholder spaces for project screenshots, UI mockups, or representative tech visualizations

### 5. Education & Certifications
**Layout**: Side-by-side cards (desktop) or stacked (mobile)

**Education Card**:
- University name, degree, GPA prominently displayed
- Graduation timeline

**Certifications Grid**:
- 2x3 grid of certification badges
- Platform logos (Coursera, Google, Microsoft, GUVI)
- Certificate names as headings
- Credential links

### 6. Contact/CTA Section
**Layout**: Centered content with generous padding (py-24)
- Headline: "Let's Build Something Amazing"
- Email and phone with copy icons
- Social links repeated (larger, more prominent)
- Background: Subtle animated gradient or pattern
- Floating contact card design with shadow depth

## Component Design Patterns

**Card Components**: 
- Rounded corners (rounded-xl)
- Border or subtle shadow for depth
- Padding: p-6 to p-8
- Hover states with transform scale-105

**Buttons**:
- Primary: Large, rounded-lg, px-8 py-4, font-semibold
- Secondary: Outlined variant
- Icon buttons: Square, rounded-full for social links

**Navigation** (Sticky header):
- Logo/Name left
- Nav links center: About, Skills, Experience, Projects, Contact
- Resume download button right
- Backdrop blur when scrolling

## Images Summary
- **Hero**: 1 large image (tech/workspace theme, right side, 800x600px+)
- **Projects**: 4 project screenshots/mockups (400x300px each)
- **Optional**: Small headshot for about section (200x200px, circular)
- All images should have subtle rounded corners and proper aspect ratio containers

## Responsive Behavior
- Mobile: Single column, stacked sections
- Tablet: 2-column grids transition
- Desktop: Full multi-column layouts with asymmetric designs
- Navigation: Hamburger menu on mobile, full nav on desktop